export const PORT = 5555;
export const mongoDBURL = 'mongodb+srv://shashwat:shashwat@cluster0.r4kuivz.mongodb.net/books-collection?retryWrites=true&w=majority&appName=Cluster0'